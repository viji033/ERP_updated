import React from 'react';
import './Hero.css';
import ab from './ab.gif';
import ProductShowcase from './ProductShowcase';
import QnA from './QnA';

const Hero = () => {
  return (<>
    <div className="hero" style={{ backgroundImage: `url(${ab})` }}>
      <div className="hero-content">

        <button>Shop Now</button>
      </div>
     
    </div>
    
     <ProductShowcase/>
     <QnA/></>
  );
};

export default Hero;