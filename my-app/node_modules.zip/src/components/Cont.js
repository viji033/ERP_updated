import React from 'react'
import Con1 from './../components/Con1'

function Component2() {
  return (
    <>
      <h1>rgregregrtgrt</h1>
      <Con1/>
    </>
  );
}

export default Component2


