import React, { useState } from 'react';

// Child component that receives both count and message as props
const Child = ({ count, message }) => {
  console.log('Child rendered');
  return (
    <div>
      <p>Count: {count}</p>
      <p>Message: {message}</p>
    </div>
  );
};

const Parent = () => {
  const [count, setCount] = useState(0);
  const [message, setMessage] = useState("Hello from Parent!");

  const incrementCount = () => {
    setCount(count + 1);
  };

  const changeMessage = () => {
    setMessage("Updated message from Parent!");
  };

  return (
    <div>
      <h1>Parent Component</h1>
      <button onClick={incrementCount}>Increment Count</button>
      <button onClick={changeMessage}>Change Message</button>

      {/* Pass both count and message as props to the Child component */}
      <Child count={count} message={message} />
    </div>
  );
};

export default Parent;
