import React, { useState, useCallback } from 'react';

// Child component that receives both count and message as props
const Child = ({ count, message, incrementCount, changeMessage }) => {
  console.log('Child rendered');
  return (
    <div>
      <p>Count: {count}</p>
      <p>Message: {message}</p>
      <button onClick={incrementCount}>Increment Count</button>
      <button onClick={changeMessage}>Change Message</button>
    </div>
  );
};

const Parent = () => {
  const [count, setCount] = useState(0);
  const [message, setMessage] = useState("Hello from Parent!");

  // Memoize the incrementCount function using useCallback
  const incrementCount = useCallback(() => {
    setCount((prevCount) => prevCount + 1);
  }, []); // This will be memoized and not recreated on each render

  // Memoize the changeMessage function using useCallback
  const changeMessage = useCallback(() => {
    setMessage("Updated message from Parent!");
  }, []); // This will also be memoized

  return (
    <div>
      <h1>Parent Component</h1>

      {/* Pass both state and memoized functions as props to the Child component */}
      <Child 
        count={count} 
        message={message} 
        incrementCount={incrementCount} 
        changeMessage={changeMessage} 
      />
    </div>
  );
};

export default Parent;
