import React, { useContext, useState } from 'react';
import './ProductShowcase.css';
import {CartContext} from './../Context/CartContext'; // Fixed import
import { Link } from 'react-router-dom';

import shirt1 from './shirt1.jpeg';
import shirt2 from './shirt2.jpeg';
import shirt3 from './shirt3.jpeg';
import shirt4 from './shirt4.jpeg';
import shirt5 from './shirt5.jpeg';
import shirt6 from './shirt6.jpeg';
import pants1 from './pants1.jpg';
import pants2 from './pants2.jpg';
import pants3 from './pants3.jpg';
import pants4 from './pants4.jpg';
import pants5 from './pants5.jpg';
import pants6 from './pants6.jpg';
import shoe1 from './shoe1.jpg';
import shoe2 from './shoe2.jpg';
import shoe3 from './shoe3.jpg';
import shoe4 from './shoe4.jpg';
import shoe5 from './shoe5.jpg';
import shoe6 from './shoe6.jpg';
import accessory1 from './bag1.jpg';
import accessory2 from './bag2.jpg';
import accessory3 from './bag3.jpg';
import accessory4 from './bag4.jpg';
import accessory5 from './bag5.jpg';
import accessory6 from './bag6.jpg';

const products = {
  shirts: [
    { id: 1, name: 'Shirt 1', price: 2000, image: shirt1 },
    { id: 2, name: 'Shirt 2', price: 2500, image: shirt2 },
    { id: 3, name: 'Shirt 3', price: 2700, image: shirt3 },
    { id: 4, name: 'Shirt 4', price: 3000, image: shirt4 },
    { id: 5, name: 'Shirt 5', price: 3200, image: shirt5 },
    { id: 6, name: 'Shirt 6', price: 3500, image: shirt6 },
  ],
  pants: [
    { id: 7, name: 'Pants 1', price: 3500, image: pants1 },
    { id: 8, name: 'Pants 2', price: 3000, image: pants2 },
    { id: 9, name: 'Pants 3', price: 2800, image: pants3 },
    { id: 10, name: 'Pants 4', price: 2600, image: pants4 },
    { id: 11, name: 'Pants 5', price: 2400, image: pants5 },
    { id: 12, name: 'Pants 6', price: 2200, image: pants6 },
  ],
  shoes: [
    { id: 13, name: 'Shoe 1', price: 1500, image: shoe1 },
    { id: 14, name: 'Shoe 2', price: 1000, image: shoe2 },
    { id: 15, name: 'Shoe 3', price: 2000, image: shoe3 },
    { id: 16, name: 'Shoe 4', price: 2500, image: shoe4 },
    { id: 17, name: 'Shoe 5', price: 3000, image: shoe5 },
    { id: 18, name: 'Shoe 6', price: 3500, image: shoe6 },
  ],
  accessories: [
    { id: 19, name: 'Bag 1', price: 2800, image: accessory1 },
    { id: 20, name: 'Bag 2', price: 3200, image: accessory2 },
    { id: 21, name: 'Bag 3', price: 2000, image: accessory3 },
    { id: 22, name: 'Accessory 4', price: 2200, image: accessory4 },
    { id: 23, name: 'Accessory 5', price: 2500, image: accessory5 },
    { id: 24, name: 'Accessory 6', price: 2700, image: accessory6 },
  ],
};

const ProductShowcase = () => {
  const { addToCart } = useContext(CartContext);
  const [selectedCategory, setSelectedCategory] = useState('shirts'); 

  return (
    <div className="product-showcase">
      <h2>Our Products</h2>

      {/* Category Selection Buttons */}
      <div className="category-buttons">
        {Object.keys(products).map((category) => (
          <button key={category} onClick={() => setSelectedCategory(category)}>
            {category.charAt(0).toUpperCase() + category.slice(1)}
          </button>
        ))}
      </div>

      {/* Display Products Based on Selected Category */}
      <div className="product-category">
        <h3>{selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)}</h3>
        <div className="products-grid">
          {products[selectedCategory].map((product) => (
            <div key={product.id} className="product-card">
              <img src={product.image} alt={product.name} />
              <h3>{product.name}</h3>
              <p>
                {product.price.toLocaleString('en-IN', { style: 'currency', currency: 'INR' })}
              </p>
              <button onClick={() => addToCart(product)}>Add to Cart</button>
            </div>
          ))}
        </div>
      </div>

      <Link to="/cart" className="view-cart-link">
        View Cart
      </Link>
    </div>
  );
};

export default ProductShowcase;
