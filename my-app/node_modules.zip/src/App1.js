import React from 'react'
import Login from './components/Login'

function App1() {
  return (
    <div>
        <Login/>
      
    </div>
  )
}

export default App1
