import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import ProductShowcase from './components/ProductShowcase';
import QnA from './components/QnA'; 
import Footer from './components/Footer';
import Cart from './components/Cart';
import Login from './components/Login';
import './App.css';

const App = () => {
  return (
    <Router>
      <div className="app-container">
        <Routes>
          <Route path="/" element={<Login />} /> 
          <Route path="/login" element={<Login />} />
          <Route path="/home" element={<><Navbar /><Hero /><Footer /></>} />
          <Route path="/products" element={<><Navbar /><ProductShowcase /><Footer /></>} />
          <Route path="/QnA" element={<><Navbar /><QnA /><Footer /></>} />
          <Route path="/cart" element={<><Navbar /><Cart /><Footer /></>} />
          
        </Routes>
      </div>
    </Router>
  );
};

export default App;

