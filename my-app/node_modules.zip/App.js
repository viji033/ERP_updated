import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import ProductShowcase from './components/ProductShowcase';
import QnA from './components/QnA'; 
import Footer from './components/Footer';
import Cart from './components/Cart';
import './App.css';

const App = () => {
  return (
    <Router>
     
        <Navbar />
        <Routes>
        <Route path="/" element={<Hero/>}/>
          <Route path="/products" element={<ProductShowcase />} />
          <Route path="/QnA" element={<QnA />} />
        <Route path='/cart' element={<Cart/>}/>
        </Routes>
        <Footer />
        
     
    </Router>
  );
};

export default App;
